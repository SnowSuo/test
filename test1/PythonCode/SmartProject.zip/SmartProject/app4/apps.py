from django.apps import AppConfig


class App4Config(AppConfig):
    name = 'app4'
