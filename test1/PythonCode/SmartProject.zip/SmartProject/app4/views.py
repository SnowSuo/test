from django.shortcuts import render,redirect
from django.http import request
from app.models import User,Supplier,SupplierContacts
import uuid
 

# Create your views here.

# 跳转主页面
def index(request):
    return render(request,'index.html')

# 跳转到供应商页面
def SupplierHome(request):
    return render(request,'SupplierHome.html')

#供应商登录业务处理
def login(request):
    if request.POST:
        #接受客户端请求数据、
        saccounts = request.POST.get('saccount',None)
        spasswords = request.POST.get('spassword',None)
        #处理请求参数
        obj =Supplier.objects.filter(saccount=saccounts, spassword=spasswords)
        if obj:
            request.session['saccount']=saccounts
            print('登录成功后写入session中')
            #响应客户端
            return redirect ('/app4/SupplierHome/')
        else:
            return render(request,'login.html')
    else:
        return render(request,'login.html')
                 

#跳转至注册页面
def register(request):
    if request.POST:
        #接受客户端输入
        sname = request.POST.get('sname',None)
        saccount = request.POST.get('saccount',None)
        spassword = request.POST.get('spassword',None)
        scode = request.POST.get('scode',None)
        sregister = request.POST.get('sregister',None)
        print(sregister,spassword,sname,saccount)
        #向表添加数据
        Supplier.objects.create(saccount=saccount,spassword=spassword,sname=sname,scode=scode,sregister=sregister )
        print('数据成功添加至数据库')
        #响应客户端
        return render(request,'login.html',{'msg':'恭喜你，已初步注册成功'})
    else:
        return render(request,'register.html') 
def SupplierMessage(request):
    SupplierMessage=SupplierMessage.objects.get(saccount=saccount)

    if request.POST:
        #接受客户端请求输入
        stype = request.POST.get('stype',None)
        squalificate = request.POST.get('squalificate',None)
        stel = int(request.POST.get('stel',None))
        sfax = int(request.POST.get('sfax',None))
        semail = request.POST.get('semail',None)
        sscope = request.POST.get('sscope',None)
        sresult = request.POST.get('sresult',None)
        stype = request.POST.get('stype',None)
        snature = request.POST.get('snature',None)
        spostcode = request.POST.get('spostcode',None)
        saddress = request.POST.get('saddress',None)
        sbank = request.POST.get('sbank',None)
        sbaccount = request.POST.get('sbaccount',None)
        staxid = request.POST.get('staxid',None)
        srcpital = request.POST.get('srcpital',None)
        sfasset = request.POST.get('sfasset',None)
        sindustry = request.POST.get('sindustry',None)
        sdeliveryarea = request.POST.get('sdeliveryarea',None)
        sarea = request.POST.get('sarea',None)
        #向数据表中添加数据
        # Supplier.objects.create(stype=stype,squalificate=squalificate,stel=stel,\
        #         sfax=sfax,semail=semail,sscope=sscope,sresult=sresult,stype=stype,snature=snature,\
        #         spostcode=spostcode,saddress=saddress,sbank=sbank,sbaccount=sbaccount,staxid=staxid,\
        #         srcpital=srcpital,sfasset=sfasset,sindustry=sindustry,sdeliveryarea=sdeliveryarea,sarea=sarea)
        return render(request,'SupplierMessage.html')
    else:
        return render(request,'SupplierMessage.html')





 
def register1(request):
    return render(request,'register1.html')
def SupplierContacts1(request):

    return render(request,'SupplierContacts.html')

def DeliveryType1(request):
    return render(request,'DeliveryType1.html')
def DeliveryType(request):
    return render(request,'DeliveryType.html')
def CompanyQualificate(request):
    return render(request,'CompanyQualificate.html')
def AddCompanyQualificate(request):
    return render(rquest,'AddCompanyQualificate')