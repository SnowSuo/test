from django.shortcuts import render
from app.models import User
from django.http import request
# Create your views here.

def index(request):
    users=User.objects.all()
    content=dict()
    content['user']=users[0]
    return render(request,'index.html', content)
