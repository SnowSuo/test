"""SmartProject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from app import views as v
urlpatterns = [
    path('admin/', admin.site.urls),
    path('app/login/',v.login),
    path('app/purchaseplan/',v.purchaseplan),
    path('app/addplan/',v.addplan),
    path('app/assignplan/',v.assignplan),
    path('app/adjustplan/',v.adjustplan),
    path('app/detailplan/',v.detailplan),
    path('app/companyplan/',v.companyplan),
    path('app/showmyplan/',v.showmyplan),
    path('app/addmaterialcategory/',v.addmaterialcategory),
    path('app/ajax/addmaterial/',v.picupload),
    path('app/ajax/addplanorder/',v.addplanorder),
    path('app/addmaterial/',v.addmaterial),
    path('app/submitplan/',v.submitplan),
    path('app/updateuser/',v.updateuser),
    path('app/validateUniquneName/<str:account>',v.validateUniquneName),
    path('app/logout/',v.logout),
    path('app/mymaterial/',v.mymaterial),
    

]
