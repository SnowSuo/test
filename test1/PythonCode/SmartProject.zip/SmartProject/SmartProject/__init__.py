#导入pymsql库
import pymysql
#设置pymysql为django默认数据库链接驱动
pymysql.install_as_MySQLdb()