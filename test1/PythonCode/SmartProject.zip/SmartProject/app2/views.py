from django.shortcuts import render, redirect
from app.models import User, TenderSheet, QuestionAnswer, Supplier, SendTender, TenderClarify
from django.http import request
# Create your views here.

def SupTenindex(request):
    return render(request, 'SupTenindex.html')
    
def welcome(request):
    return render(request, 'welcome.html')

def queryAllTenderSheet(request):
    return render(request, 'SupTenshowTenderSheet.html')

def tssearch(request):
    tscode = request.POST.get('tscode1', None)
    lstTenderSheets = TenderSheet.objects.filter(tscode=tscode)
    context=dict()
    context['lstTenderSheets'] = lstTenderSheets
    return render(request, 'SupTenshowTenderSheet.html', context)

def attendTender(request, id):
    obj = TenderSheet.objects.filter(tsid = id)
    # print(obj)
    content=dict()
    content['objs'] = obj
    return render(request, 'SupTenattendTender.html',content)

def clarifyTender(request):
    return render(request, 'SupTenclarifyTender.html')

def replyTender(request):
    if request.POST:
        # 接收客户端请求数据
        tcexplain = request.POST.get('tcexplain', None)
        # tcattchment = request.POST.get('tcattchment', None)
        return redirect('/TenderSheet/uploadFile/')
    else:
        return render(request, 'SupTenreplyTender.html')

def question(request):
    if request.POST:
        qaquestion = request.POST.get('qaquestion', None)
        tsid = int(request.POST.get('qatsheet', None))
        qatsheet = TenderSheet.objects.get(tsid = tsid)
        # 处理数据（添加数据表）
        QuestionAnswer.objects.create(qaquestion = qaquestion, qatsheet = qatsheet)
        lstQuestionAnswers = QuestionAnswer.objects.all()    
        # 封装到传递参数中
        context = dict()
        context['lstQuestionAnswers'] = lstQuestionAnswers
        # 页面响应跳转
        return render(request, 'SupTenquestionanswer.html', context)
    else:
        tendersheetInfos = TenderSheet.objects.all()
        context = dict()
        context['tendersheetInfos'] = tendersheetInfos
        # 响应客户端（页面跳转）
        return render(request, 'SupTenquestionanswer.html', context)

def uploadFile(request):
    if request.POST:
        # 接收客户端请求数据
        stattachment = request.POST.get('stattachment', None)
        tsid = int(request.POST.get('sttendsheet', None))
        sttendsheet = TenderSheet.objects.get(tsid = tsid)
        sid = int(request.POST.get('stsender', None))
        stsender = Supplier.objects.get(sid = sid)
        SendTender.objects.create(stattachment=stattachment, sttendsheet=sttendsheet, stsender=stsender)
        import os
        print('\n文件名称：{0}'.format(stattachment))
        uploadPath = os.path.join(os.getcwd(), 'app2/static/file')
        if not os.path.exists(uploadPath):
            os.mkdir(uploadPath)
            print('上传文件夹创建完毕.')
            print('服务器上传文件夹地址：{0}\n'.format(uploadPath))
        else:
            print('服务器上传文件夹地址存在.')
        # 设置上传文件服务器端全路径
        uploadFileFullPath = uploadPath + os.sep + stattachment
        # 文件写入操作
        try:
            with open(uploadFileFullPath, 'wb+') as fp:
                # # 将上传文件拆分成多个块（当上传文件大于2.5MB时，自动拆分）
                # for chunk in obj.chunks():
                fp.write(chunk)
            print('服务器文件写入完毕.\n')
            # 响应客户端
            return redirect('/TenderSheet/queryallSendTender/')
        except:
            print('服务器文件写入失败.\n')
            # 响应客户端
            return redirect('/TenderSheet/queryallSendTender/')
    else:
        tendersheetInfos = TenderSheet.objects.all()
        supplierInfos = Supplier.objects.all()
        context = dict()
        context['tendersheetInfos'] = tendersheetInfos
        context['supplierInfos'] = supplierInfos
        return render(request, 'SupTenuploadFile.html', context)

def queryAllSendTender(request):
    # 查询TenderSheet数据表的全部信息
    lstSendTenders = SendTender.objects.all()
    context = dict()
    context['lstSendTenders'] = lstSendTenders
    # 响应客户端
    return render(request, 'SupTenshowSendTender.html', context)

def deleteSendTender(request, id):
    SendTender.objects.filter(stid = id).delete()
    # 响应客户端
    return redirect('/TenderSheet/queryallSendTender/')

def preUpdateSendTender(request, id):
    obj = SendTender.objects.get(stid = id)
    tendersheetInfos = TenderSheet.objects.all().values_list('tsid', 'tsname')
    supplierInfos = Supplier.objects.all().values_list('sid', 'sname')
    context = dict()
    context['sendtender'] = obj
    context['tendersheetInfos'] = tendersheetInfos
    context['supplierInfos'] = supplierInfos
    return render(request, 'SupTenupdateSendTender.html', context)

def updateSendTender(request):
    if request.POST:
        # 接收客户端请求数据
        stid = int(request.POST.get('stid', None))
        stattachment = request.POST.get('stattachment', None)
        # 处理数据（更新操作）
        SendTender.objects.filter(stid = stid).update(stattachment=stattachment)
        # 响应客户端
        return redirect('/TenderSheet/queryallSendTender/')

def uploadClarify(request):
    if request.POST:
        # 接收客户端请求数据
        tctime = request.POST.get('tctime', None)
        tcexplain = request.POST.get('tcexplain', None)
        tcattachment = request.POST.get('tcattachment', None)
        tsid = int(request.POST.get('tctsheet', None))
        tctsheet = TenderSheet.objects.get(tsid = tsid)
        TenderClarify.objects.create(tctime=tctime,tcexplain=tcexplain,tcattachment=tcattachment, tctsheet=tctsheet)
        lstTenderClarifys = TenderClarify.objects.all()
        context = dict()
        context['lstTenderClarifys'] = lstTenderClarifys
        import os
        print('\n文件名称：{0}'.format(tcattachment))
        uploadPath = os.path.join(os.getcwd(), 'app2/static/file')
        if not os.path.exists(uploadPath):
            os.mkdir(uploadPath)
            print('上传文件夹创建完毕.')
            print('服务器上传文件夹地址：{0}\n'.format(uploadPath))
        else:
            print('服务器上传文件夹地址存在.')
        # 设置上传文件服务器端全路径
        uploadFileFullPath = uploadPath + os.sep + tcattachment
        # 文件写入操作
        try:
            with open(uploadFileFullPath, 'wb+') as fp:
                fp.write()
            print('服务器文件写入完毕.\n')
            # 响应客户端
            return render(request, 'SupTenuploadClarify.html',context)
        except:
            print('服务器文件写入失败.\n')
            # 响应客户端
        return render(request, 'SupTenuploadClarify.html',context)
    else:
        tendersheetInfos =TenderSheet.objects.all()
        lstTenderClarifys = TenderClarify.objects.all()
        context = dict()
        context['tendersheetInfos'] = tendersheetInfos
        context['lstTenderClarifys'] = lstTenderClarifys
        return render(request, 'SupTenuploadClarify.html', context)

