from django.shortcuts import render,redirect
from app.models import User,PurchasePlan,Material,MaterialCategory,Order,SupplierContacts,InquirySheet,Company,ProjectTeam,Dept,BResponse
from django.http import request,HttpResponseRedirect
import datetime,time

# Create your views here.
def ppsearch(request):
    if request.POST:
        ppcode=request.POST.get('ppcode1',None)
        mname=request.POST.get('mname',None)
        ppname=request.POST.get('ppname',None)
        username=request.POST.get('user',None)
        PurchasePlans1=PurchasePlan.objects.filter(ppcode=ppcode) #采购计划
        Materials=Material.objects.filter(mname=mname)
        PurchasePlans2=[] # 物料对应的采购计划集
        PurchasePlans=[]#所有采购计划
        if len(Materials)>0 :
            ordersList=Materials[0].order_set.all()
            for order_mi in ordersList:
                PurchasePlans2.append(order_mi.orderpp)
        PurchasePlans3=PurchasePlan.objects.filter(ppname=ppname) #采购计划
        PurchasePlans4=PurchasePlan.objects.filter(ppacceptor_id=username) #采购计划
        PurchasePlans.append(list(PurchasePlans1))
        PurchasePlans.append(list(PurchasePlans2))
        PurchasePlans.append(list(PurchasePlans3))
        PurchasePlans.append(list(PurchasePlans4))
        content=dict()
        plans=[]
        for i in PurchasePlans:
            if i:
                plans.append(i)
        if plans==[]:
            newplans=[]
        else:
            newplans=plans[0]
        for i in range(0,len(plans) ):
            for j in newplans:
                if j not in plans[i]:
                    newplans.remove(j)   
        content['PurchasePlans']=newplans
        users=User.objects.all()
        content['users']=users
        return render(request,'ppsearch.html',content)
    else:
        users=User.objects.all()
        content=dict()
        content['users']=users
        return render(request,'ppsearch.html',content)

def ppdetailsearch(request):
    return render(request,'ppdetailsearch.html')
def ppdetail(request,ppcode):
    PurchasePlans=PurchasePlan.objects.get(ppcode=ppcode)
    content=dict()
    content['PurchasePlan']=PurchasePlans
    return render(request,'ppdetail.html',content)
def ppaccept(request):
    if request.POST:
        ppcode=request.POST.get('ppcode1',None)
        mname=request.POST.get('mname',None)
        ppname=request.POST.get('ppname',None)
        username=request.POST.get('user',None)
        PurchasePlans1=PurchasePlan.objects.filter(ppcode=ppcode) #采购计划
        Materials=list(Material.objects.filter(mname=mname))
        PurchasePlans2=[] # 物料对应的采购计划集
        PurchasePlans=[]#所有采购计划
        if len(Materials)>0 :
            ordersList=Materials[0].order_set.all()
            for order_mi in ordersList:
                PurchasePlans2.append(order_mi.orderpp)
        PurchasePlans3=PurchasePlan.objects.filter(ppname=ppname) #采购计划
        PurchasePlans4=PurchasePlan.objects.filter(ppacceptor_id=username) #采购计划
        PurchasePlans.append(list(PurchasePlans1))
        PurchasePlans.append(list(PurchasePlans2))
        PurchasePlans.append(list(PurchasePlans3))
        PurchasePlans.append(list(PurchasePlans4))
        content=dict()
        plans=[]
        for i in PurchasePlans:
            if i:
                plans.append(i)
        newplans=[]
        if plans==[]:
            newplans=[]
        else:
            newplans=plans[0]
        for i in range(0,len(plans) ):
            for j in newplans:
                if j not in plans[i]:
                    newplans.remove(j)   
        content['PurchasePlans']=newplans
        users=User.objects.all()
        content['users']=users
        return render(request,'ppaccept.html',content)
    else:
        users=User.objects.all()
        PurchasePlansa=PurchasePlan.objects.filter(ppstate='已受理')
        PurchasePlansb=PurchasePlan.objects.all()
        PurchasePlans=[i for i in PurchasePlansb if i not in PurchasePlansa]
        content=dict()
        content['users']=users
        Materials=Material.objects.all()
        content['Materials']=Materials
        content['PurchasePlans']=PurchasePlans
        return render(request,'ppaccept.html',content)

def operation1(request,ppcode):
    PurchasePlans=PurchasePlan.objects.get(ppcode=ppcode)
    SupplierContact=SupplierContacts.objects.all()
    content=dict()
    content['PurchasePlan']=PurchasePlans
    content['SupplierContacts']=SupplierContact
    if request.POST:
        ppnote=request.POST.get('ppnote',None)
        ppstate=request.POST.get('ppstate',None)
        PurchasePlan.objects.filter(ppcode = ppcode).update(ppnote = ppnote, ppstate= ppstate)
        return render(request,'operation1.html',content)
    else:
        return render(request,'operation1.html',content)
        
def addtendersheet(request,ppcode):
    # 实现询比信息单的添加操作
    isplan = PurchasePlan.objects.get(ppcode=ppcode)
    # print(isplan)
    context = dict()
    context['isplan'] = isplan
    if request.POST:
        d = datetime.datetime.fromtimestamp(time.time())
        # 接收客户端请求数据
        iscode ='CGXJ'+d.strftime('%Y%m%d%H%M%S%f')
        # print(iscode)
        bisplan = isplan.ppid
        # print(bisplan)
        istype =request.POST.get('istype',None)
        # print(istype)
        isstate =request.POST.get('isstate',None)
        # print(isstate)
        iscutoff =request.POST.get('iscutoff',None)
        isquotetype =request.POST.get('isquotetype',None)
        isnotice =request.POST.get('isnotice',None)
        istaxrate =float(request.POST.get('istaxrate',None))    
        isorder = isplan.order_set.all()[0]
        # print(isorder)
        # isorder =request.POST.get('isorder',None)
        iscreatetime = d.strftime('%Y-%m-%d %H:%M:%S')
        isresponse =request.POST.get('isresponse',None)
        istaxprice =request.POST.get('istaxprice',None)
        isnote =request.POST.get('isnote',None)
        isattachment ='1.doc'
        # print(isattachment)
        # 处理请求数据（向数据库添加）
        InquirySheet.objects.create(iscode=iscode,istype=istype,iscutoff=iscutoff,isquotetype=isquotetype,
                                    isnotice=isnotice,isorder=isorder,isresponse=isresponse,isstate=isstate,
                                    istaxprice=istaxprice,istaxrate=istaxrate,isnote=isnote,
                                    iscreatetime=iscreatetime,isattachment=isattachment)
        # 响应客户端（查询结果使用重定向跳转，防止重复操作）
        return render(request,'tbresponse.html',context)
    else:
        # 响应客户端（页面跳转）
        return render(request,'addtendersheet.html',context)
def tbresponse(request,ppcode):
    print(ppcode)
    isplan = PurchasePlan.objects.get(ppcode=ppcode)
    print(isplan)
    bresponses = BResponse.objects.all()
    context = dict()
    context['bresponses'] = bresponses
    print(bresponses)
    context['isplan'] = isplan
    if request.POST:
        brid = request.POST.get('bresponse',None)
        print(brid)
        brdeliverydate1 = request.POST.get('brdeliverydate',None)
        brdeliverydate = datetime.datetime.strptime(brdeliverydate1, '%Y-%m-%d').date()
        print(type(brdeliverydate))  
        brbillmethod = request.POST.get('brbillmethod',None)
        print(brbillmethod)
        brquality = request.POST.get('brquality',None)
        print(brquality)
        brdeliverymethod = request.POST.get('brdeliverymethod',None)
        print(brdeliverymethod)
        brexpences = request.POST.get('brexpences',None)
        print(brexpences)
        brpaymethod = request.POST.get('brpaymethod',None)
        print(brpaymethod)
        bracceptmethod = request.POST.get('bracceptmethod',None)
        print(bracceptmethod)
        brpackmethod = request.POST.get('brpackmethod',None)
        print(brpackmethod)
        brcurrency = request.POST.get('brcurrency',None)
        print(brcurrency)
        brfare = request.POST.get('brfare',None)
        print(brfare)
        B = BResponse.objects.filter(brdeliverydate=brdeliverydate,brbillmethod=brbillmethod,
                                     brquality=brquality,brdeliverymethod=brdeliverymethod,
                                     brexpences=brexpences,brpaymethod=brpaymethod)
        print(B)
        #BResponse.objects.create()
    else:
        return render(request,'tbresponse.html',context)
def tchecksupplier(request):
    return render(request,'tchecksupplier.html')
def tendersummary(request):
    return render(request,'tendersummary.html')
def tprojectteam(request):
    return render(request,'tprojectteam.html')
def tispreview(request):
    return render(request,'tispreview.html')
def evaluategroup(request,iscode):
    InquirySheets=list(InquirySheet.objects.filter(iscode=iscode))
    content=dict()
    if request.POST:
        Companys=Company.objects.all()
        users=User.objects.all()
        company=request.POST.get('company',None)
        user=request.POST.get('username',None)
        did=request.POST.get('dept',None)
        memberid=request.POST.get('ptmember',None)
        print()
        ProjectTeam.objects.create(ptmember=memberid,ptinquirysheet=InquirySheets[0].iscode)
        ptmembers1=[]
        ptmembers=[]
        Companys1=list(Company.objects.filter(cid=company))
        if len(Companys1)>0 :
            ptmembers1a=Companys1[0].user_set.all()
            for ptmember in ptmembers1a:
                ptmembers1.append(ptmember)
        ptmembers2=list(User.objects.filter(uid=user))
        ptmembers3=[]
        depts=list(Dept.objects.filter(did=did))
        if len(depts)>0 :
            ptmembers3a=depts[0].user_set.all()
            for ptmember in ptmembers3a:
                ptmembers3.append(ptmember)
        ptmembers.append(ptmembers1)
        ptmembers.append(ptmembers2)
        ptmembers.append(ptmembers3)
        nptmembers=[]
        for i in ptmembers:
            if i:
                nptmembers.append(i)
        if nptmembers==[]:
            newptmembers=[]
        else:
            newptmembers=nptmembers[0]
        for i in range(0,len(nptmembers) ):
            for j in newptmembers:
                if j not in nptmembers[i]:
                    newptmembers.remove(j) 
        content['InquirySheet']=list(InquirySheets)[0]
        content['Companys']=Companys
        content['users']=users
        content['ptmembers']=newptmembers
        return render(request,'evaluategroup.html',content)
    else:
        Companys=Company.objects.all()
        users=User.objects.all()
        content['InquirySheet']=list(InquirySheets)[0]
        content['Companys']=Companys
        content['users']=users
        return render(request,'evaluategroup.html',content)
        
def topentender(request):
    return render(request,'topentender.html')
def evaluatesign(request):
    return render(request,'evaluatesign.html')
def ispplan(request):
    isplans = PurchasePlan.objects.filter(pptype='询价')
    context = dict()
    context['isplans'] = isplans
    return render(request,'ispplan.html',context)
def openinquiryhome(request):
    PurchasePlans=PurchasePlan.objects.filter(ppstate='已受理')
    content=dict()
    Materials=Material.objects.all()
    content['Materials']=Materials

    content['PurchasePlans']=PurchasePlans
    return render(request,'openinquiryhome.html',content)
def inquiryhome(request):
    return render(request,'inquiryhome.html')
def checkinquiry(request,iscode):
    InquirySheets=InquirySheet.objects.filter(iscode=iscode)
    content=dict()
    content['InquirySheet']=list(InquirySheets)[0]
    return render(request,'checkinquiry.html',content)
def tobresponse(request,brid):
    bresponse = BResponse.objects.filter(brid=brid)
    bresponses = BResponse.objects.all()
    context = dict()
    context['bresponses'] = bresponses
    context['bresponse'] = bresponse[0]
    return render(request,'tbresponse.html',context)
    


    







