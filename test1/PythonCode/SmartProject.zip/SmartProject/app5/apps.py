from django.apps import AppConfig


class App5Config(AppConfig):
    name = 'app5'
