﻿from django.db import models


# Create your models here.
#创建用户数据表
class User(models.Model):
    uid=models.AutoField(primary_key=True)
    uname=models.CharField(max_length=30)
    upassword=models.CharField(max_length=30)
    uphone=models.CharField(max_length=30)
    utel=models.CharField(max_length=30)
    uemail=models.CharField(max_length=30)
    umajor=models.CharField(max_length=30)#所属专业
    ucompany=models.ForeignKey('Company',on_delete=models.CASCADE)#外键#所属公司单位
    udepartment=models.ForeignKey('Dept',on_delete=models.CASCADE)#外键

 #创建部门数据表
class Dept(models.Model):
    did=models.AutoField(primary_key=True)
    dname=models.CharField(max_length=30)

#创建公司数据表
class Company(models.Model):
    cid=models.AutoField(primary_key=True)
    cname=models.CharField(max_length=30)

#创建采购计划数据表
class PurchasePlan(models.Model):
    ppid=models.AutoField(primary_key=True)
    ppcode=models.CharField(max_length=30,null=True)#采购计划编号
    ppname=models.CharField(max_length=30)#项目名称
    ppnative=models.CharField(max_length=100)#交货地
    ppapplytime=models.CharField(max_length=30)#申请时间
    ppdealtime=models.CharField(max_length=30)#交易时间
    pptype=models.CharField(max_length=30)#采购类型（招标或询价）
    ppmoney=models.FloatField(max_length=30)#采购金额
    ppcategory=models.CharField(max_length=30)#计划类型（紧急或普通）
    ppstate=models.CharField(max_length=30)#状态
    ppacceptor=models.ForeignKey('User', related_name='user1',on_delete=models.CASCADE)#受理人
    ppcompany=models.ForeignKey('Company', related_name='company1',on_delete=models.CASCADE)#采购单位
    ppneedcompany=models.ForeignKey('Company',related_name='company2',on_delete=models.CASCADE)#需用单位
    ppnote=models.TextField()#备注
    ppcharge=models.ForeignKey('User',related_name='user2',on_delete=models.CASCADE)#负责人
    ppcreator=models.ForeignKey('User',related_name='user3',on_delete=models.CASCADE)#创建人

#创建物料类别数据表
class MaterialCategory(models.Model):
    mcid=models.AutoField(primary_key=True)
    mcname=models.CharField(max_length=30)#物料类别名称


#创建物料表
class Material(models.Model):
    mid=models.AutoField(primary_key=True)
    mcode=models.CharField(max_length=30,null=True)#物料编号
    mname=models.CharField(max_length=30)#物料名称
    mmunit=models.CharField(max_length=30)#计量单位
    mtype=models.CharField(max_length=30)#物料型号规格
    mprice=models.FloatField(max_length=30)#单价
    mcategory=models.ForeignKey('MaterialCategory',on_delete=models.CASCADE)#类别
    mpic=models.CharField(max_length=160,null=True)#物料图片

#创建采购单
class Order(models.Model):
    oid=models.AutoField(primary_key=True)
    onumber=models.IntegerField()#采购数量
    ocode=models.ForeignKey('Material',on_delete=models.CASCADE)#物料编码
    orderpp=models.ForeignKey('PurchasePlan',on_delete=models.CASCADE)#所属采购计划编号
    oadvisesupplier1=models.ForeignKey('SupplierContacts',related_name='contract1',on_delete=models.CASCADE)#推荐供应商1
    oadvisesupplier2=models.ForeignKey('SupplierContacts',related_name='contract2',on_delete=models.CASCADE)#推荐供应商2
    oadvisesupplier3=models.ForeignKey('SupplierContacts',related_name='contract3',on_delete=models.CASCADE)#推荐供应商3

#创建品牌
class Brand(models.Model):
    bid=models.AutoField(primary_key=True)
    bname=models.CharField(max_length=30)#品牌名称

#创建品牌代理表
class BrandAgent(models.Model):
    baid=models.AutoField(primary_key=True)
    basupplier=models.ForeignKey('Brand',related_name='brand1',on_delete=models.CASCADE)#品牌代理供应商
    babrand=models.ForeignKey('Brand',related_name='brand2',on_delete=models.CASCADE)#代理品牌

#创建询价单数据表模型
class InquirySheet(models.Model):
    isid=models.AutoField(primary_key=True)
    iscode=models.CharField(max_length=30)#询价单编号
    istype=models.CharField(max_length=30)#询比价类型
    iscutoff=models.DateTimeField()#报价截止日期
    isquotetype=models.CharField(max_length=30)#报价类型
    isnotice=models.CharField(max_length=30)#是否公告
    isorder=models.ForeignKey('Order',on_delete=models.CASCADE)#所属采购单
    isresponse=models.ForeignKey('BResponse',on_delete=models.CASCADE)#商务响应 
    isnote=models.TextField()#备注
    isattachment=models.CharField(max_length=100)#附件
    isstate=models.CharField(max_length=30)#状态（待审理，）
    istaxrate=models.FloatField()#税率
    istaxprice=models.FloatField()#含税价
    iscreatetime=models.DateTimeField()#发布时间
    iswin=models.ForeignKey('Supplier',on_delete=models.CASCADE,null=True)#中标人

#创建商务响应
class BResponse(models.Model):
    brid=models.AutoField(primary_key=True)
    brdeliverydate=models.DateTimeField()#交货时间
    brbillmethod=models.CharField(max_length=30)#结算方式
    brquality=models.CharField(max_length=30)#质量要求
    brdeliverymethod=models.CharField(max_length=30)#交货方式
    brexpences=models.CharField(max_length=30)#费用承担方
    brpaymethod=models.CharField(max_length=30)#付款方式
    bracceptmethod=models.CharField(max_length=30)#验收方式
    brpackmethod=models.CharField(max_length=30)#包装方式
    brcurrency=models.CharField(max_length=30)#币种
    brfare=models.FloatField(max_length=30)#运费

#创建供应商数据表
class Supplier(models.Model):
    sid=models.AutoField(primary_key=True)
    scode=models.CharField(max_length=30)#编码
    sname=models.CharField(max_length=100)#公司名称
    #squalificate=models.ForeignKey('CompanyQualificate',on_delete=models.CASCADE,null=True)#资质文件名
    stel=models.CharField(max_length=30,null=True)#电话
    sfax=models.CharField(max_length=30,null=True)#传真
    semail=models.CharField(max_length=30,null=True)#邮件
    sscope=models.CharField(max_length=30,null=True)#经营范围
    sresult=models.CharField(max_length=30,null=True)#经营业绩
    sregister=models.DateField()#注册时间
    saccount=models.CharField(max_length=30)#用户名
    spassword=models.CharField(max_length=30)#用户密码
    stype=models.CharField(max_length=30,null=True)#企业类型
    snature=models.CharField(max_length=30,null=True)#企业性质
    spostcode=models.CharField(max_length=30,null=True)#邮编
    saddress=models.CharField(max_length=100,null=True)#企业地址
    sbank=models.CharField(max_length=30,null=True)#开户银行
    sbaccount=models.CharField(max_length=30,null=True)#银行账号
    staxid=models.CharField(max_length=30,null=True)#税号
    srcpital=models.IntegerField(null=True)#注册资金
    sfasset=models.IntegerField(null=True)#固定资产
    sindustry=models.CharField(max_length=30,null=True)#所属行业
    sdeliveryarea=models.CharField(max_length=30,null=True)#交货地域
    sarea=models.CharField(max_length=30,null=True)#所属区域

#创建供应商联系人数据表
class SupplierContacts(models.Model):
    scid=models.AutoField(primary_key=True)
    sccode=models.CharField(max_length=30)#编码
    scname=models.CharField(max_length=30)#姓名
    sctel=models.CharField(max_length=30)#电话(座机)
    scsupplier=models.ForeignKey('Supplier',on_delete=models.CASCADE)#所属供应商
    scsex=models.CharField(max_length=30)#性别
    scjob=models.CharField(max_length=30)#职务
    scdepartment=models.CharField(max_length=30)#部门
    scidnumber=models.CharField(max_length=30)#身份证号
    scphone=models.CharField(max_length=30)#手机号

# 创建公司资质文件数据表
class CompanyQualificate(models.Model):
    cqid=models.AutoField(primary_key=True)
    cqsupplier=models.ForeignKey('Supplier',on_delete=models.CASCADE)#所属供应商
    cqname=models.CharField(max_length=30)#证书名称
    cqagency=models.CharField(max_length=30)#发证机构
    cqcode=models.CharField(max_length=30)#证书编号
    cqvperiod=models.DateField()#有效日期
    cqnote=models.TextField()#备注

# 创建供货关系数据表
class DeliveryRelation(models.Model):
    drid=models.AutoField(primary_key=True)
    drmaterial=models.ForeignKey('Material',on_delete=models.CASCADE)#可供物料
    drsupplier=models.ForeignKey('Supplier',on_delete=models.CASCADE)#所属供应商

# 创建项目组成员（组）数据表
class ProjectTeam(models.Model):
    ptid=models.AutoField(primary_key=True)
    ptinquirysheet=models.ForeignKey('InquirySheet',on_delete=models.CASCADE)#所属询价单
    ptmember=models.ForeignKey('User',on_delete=models.CASCADE)#组员

# 创建招标信息单
class TenderSheet(models.Model):
    tsid=models.AutoField(primary_key=True)
    tsname=models.CharField(max_length=30)#招标单名称
    tscode=models.CharField(max_length=30)#招标信息编号
    tstype=models.CharField(max_length=30)#项目类型（招标方式）
    tsawardmethod=models.CharField(max_length=30)#决标方式
    tsmin=models.CharField(max_length=30)#最小投标单位
    tsquotetype=models.CharField(max_length=30)#报价类型
    tscutoff=models.DateTimeField()#投标截止日期
    tswhether=models.CharField(max_length=30)#是否发布公告
    tswin=models.ForeignKey('Supplier',on_delete=models.CASCADE,null=True)#中标人（供应商）
    tsamount=models.FloatField()#招标总额
    tsstate=models.CharField(max_length=30)#状态
    tstaxrate=models.FloatField()#税率
    tsnote=models.TextField()#备注
    tsorder=models.ForeignKey('Order',on_delete=models.CASCADE)#所属采购单
    tsresponse=models.ForeignKey('BResponse',on_delete=models.CASCADE)#商务响应
    tstime=models.DateTimeField()#发布时间

#创建招标概要
class TenderSummary(models.Model):
    tid=models.AutoField(primary_key=True)
    tptime=models.FloatField()#正式发布时间
    tsdealtime=models.FloatField()#投标截止时间
    totime=models.FloatField()#开标时间
    tetime=models.FloatField()#评标时间
    tocommand=models.CharField(max_length=30)#开标口令
    tomethod=models.CharField(max_length=30)#开标方式
    tfile=models.CharField(max_length=30)#标书文件
    ttsheet=models.ForeignKey('TenderSheet',on_delete=models.CASCADE)#所属招标单

#创建问题解答数据表
class QuestionAnswer(models.Model):
    qaid=models.AutoField(primary_key=True)
    qatsheet=models.ForeignKey('TenderSheet',on_delete=models.CASCADE)#所属招标单
    qaquestion=models.TextField()#问题
    qaanswer=models.TextField()#问题解答
    qareplyer=models.ForeignKey('User',on_delete=models.CASCADE)#回复者
    qareplytime=models.DateTimeField()#回复时间

#创建评标规则数据表
class EvaluateRule(models.Model):
    erid=models.AutoField(primary_key=True)
    ername=models.CharField(max_length=30)#规则名称
    ercreater=models.CharField(max_length=30)#创建者
    ertype=models.CharField(max_length=30)#规则类型（技术，商务）
    erapplytype=models.CharField(max_length=30)#应用类型（供应商评估，项目评估）
    erexplain=models.CharField(max_length=30)#规则说明
    ercreatetime=models.DateTimeField()#创建时间
    erscore=models.CharField(max_length=30)#分值

#评标组
class EvaluateGroup(models.Model):
    egid=models.AutoField(primary_key=True)
    eguser=models.ForeignKey('User',on_delete=models.CASCADE)#评标人
    egtsheet=models.ForeignKey('TenderSheet',on_delete=models.CASCADE)#所属招标单

#评标签到
class EvaluateSign(models.Model):
    esid=models.AutoField(primary_key=True)
    eseg=models.ForeignKey('EvaluateGroup',related_name='group1',on_delete=models.CASCADE)#所属评标组
    esuser=models.ForeignKey('EvaluateGroup',related_name='group2',on_delete=models.CASCADE)#签到人
    estime=models.DateTimeField()#签到时间

#评标数据表
class Evaluation(models.Model):
    eid=models.AutoField(primary_key=True)
    etsheet=models.ForeignKey('TenderSheet',on_delete=models.CASCADE)#所属招标单
    eerule=models.ForeignKey('EvaluateRule',on_delete=models.CASCADE)#评标规则
    euser=models.ForeignKey('User',on_delete=models.CASCADE)#评标人
    etime=models.DateTimeField()
    escore=models.CharField(max_length=30)

#标后澄清
class TenderClarify(models.Model):
    tcid=models.AutoField(primary_key=True)
    tctsheet=models.ForeignKey('TenderSheet',on_delete=models.CASCADE)#所属招标单
    tctime=models.DateTimeField()#澄清时间
    tcexplain=models.TextField()#澄清说明
    tcattachment=models.CharField(max_length=30)#上传附件

#创建商务合同
class BusinessContract(models.Model):
    bcid=models.AutoField(primary_key=True)
    bccode=models.CharField(max_length=30)#合同编号
    bctsheet=models.ForeignKey('TenderSheet',on_delete=models.CASCADE)#所属招标单
    bccreater=models.ForeignKey('User',related_name='user4',on_delete=models.CASCADE)#创建人
    bcman=models.ForeignKey('User',related_name='user5',on_delete=models.CASCADE)#签约人
    bcexecutor=models.ForeignKey('User',related_name='user6',on_delete=models.CASCADE)#执行者
    bctime=models.DateTimeField()#签约时间
    bcstate=models.CharField(max_length=30)#合同状态

#创建投标单
class SendTender(models.Model):
    stid=models.AutoField(primary_key=True)
    sttendsheet=models.ForeignKey('TenderSheet',on_delete=models.CASCADE)#所属招标单
    stattachment=models.CharField(max_length=30)#附件
    stsender=models.ForeignKey('Supplier',on_delete=models.CASCADE,null=True)#投标人
