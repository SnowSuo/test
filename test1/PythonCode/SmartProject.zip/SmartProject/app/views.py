from django.shortcuts import render,redirect
import uuid
import os,time,datetime
from app.models import User,MaterialCategory,Material,Order,PurchasePlan,Company,Dept,Supplier,SupplierContacts,Dept
from django.http import request,HttpResponse
from django.core.paginator import Paginator,EmptyPage,PageNotAnInteger
# Create your views here.

#登录
def login(request):
    if request.POST:
        account=request.POST.get('account',None)
        password=request.POST.get('password',None)
        obj = User.objects.filter(uname = account ,upassword= password)
        if obj:
            request.session['account']=account
            print('登录成功后写入session')
            return render(request,'purchaseplan.html',{'account':account})
        else:
            return render(request,'login.html',{'message':'密码或账号输入有误'})
    else:
        return render(request,'login.html')
#用户退出
def logout(request):
    account=request.session.get('account',None)
    if not account:
        return redirect('/app/login/')
    else:
        #删除当前登陆者session的信息
        del request.session['account']
        print('删除当前登录者信息')
        return redirect('/app/login/')
#用户密码修改
def updateuser(request):
    if request.POST:
        return render(request,'updateuser.html')
    else:
        return render(request,'updateuser.html')
#用户名唯一验证
def validateUniquneName(request,account):
    obj= User.objects.filter(uname = account )
    print(obj)
    #定义一个标识位
    flag=True
    #判断客户端请求用户名是否存在
    if obj:
        flag=False
        import time
        time.sleep(3)
        return HttpResponse(flag)

def purchaseplan(request):
    if not account:
        return render(request,'login.html')
    else:
    
        return render(request,'purchaseplan.html')
       
#创建计划
def addplan(request):
    account=request.session.get('account',None)
    deptno=list(User.objects.filter(uname=account))[0].udepartment.did
    if not account:
        return render(request,'login.html')
    else:
        if deptno == 3:
            if request.POST:
                return render(request,'addplan.html')
            else:
                users=User.objects.all()
                #使用函数获取数据库全部信息集合
                lstobjs=Material.objects.all()
                #创建分页器类并设置每页显示的数据格式
                paginator=Paginator(lstobjs,3)
                #接收客户端传入页码
                page=request.GET.get('page')
                #根据用户传入页码返回响应页面数据集
                try:
                    lstobjs=paginator.page(page)
                except EmptyPage:
                    lstobjs=paginator.page(1)
                except PageNotAnInteger:
                    lstobjs=paginator.page(paginator.num_pages)
                companys=Company.objects.all()
                contracts=SupplierContacts.objects.all()
                purchaseplan=PurchasePlan.objects.all()
                print(purchaseplan)
                context=dict()
                context['materials']=lstobjs
                context['users']=users
                context['companys']=companys
                context['contracts']=contracts#获取供应商联系人
                purchaseplans=[]
                purchaseplans.append(list(purchaseplan)[-1])
                context['purchaseplan']=purchaseplans
                return render(request,'addplan.html',context)
        else:
            return render(request,'tishi.html',{'msg':'仅计划员可操作访问'})

#创建计划单
def addplanorder(request):
    if request.POST:
        print('开始获取数据')
        d = datetime.datetime.fromtimestamp(time.time())
        # 接收客户端请求数据
        ppcode ='CGJH'+d.strftime('%Y%m%d%H%M%S%f')
        ppname=request.POST.get('ppname',None)
        ppapplytime=request.POST.get('ppapplytime',None)
        pptype=request.POST.get('pptype',None)
        ppneedcompany=int(request.POST.get('ppneedcompany',None))
        ppcategory=request.POST.get('ppcategory',None)
        ppcompany=int(request.POST.get('ppcompany',None))
        ppnative=request.POST.get('ppnative',None)
        ppdealtime=request.POST.get('ppdealtime',None)
        ppmoney=request.POST.get('ppmoney',None)
        ppcreator=int(request.POST.get('ppcreator',None))
        ppcharge=int(request.POST.get('ppcharge',None))
        ppstate=request.POST.get('ppstate',None)
        ppnote=request.POST.get('ppnote',None)
        ppacceptor=int(request.POST.get('ppacceptor',None))
        #添加至数据库
        PurchasePlan.objects.create(ppcode=ppcode,ppname=ppname,ppapplytime=ppapplytime,\
        pptype=pptype,ppneedcompany_id=ppneedcompany,ppcategory=ppcategory,ppcompany_id=ppcompany,ppnative=ppnative,\
        ppdealtime=ppdealtime,ppmoney=ppmoney,ppcreator_id=ppcreator,ppcharge_id=ppcharge,ppnote=ppnote,\
        ppacceptor_id=ppacceptor,ppstate=ppstate)
        print('数据成功添加至数据库')
        return redirect('/app/addplan/')
    


#计划提交
def submitplan(request):
    if request.POST:
        print('开始获取数据')
        ocode=request.POST.get('ocode',None)
        orderpp=request.POST.get('orderpp',None)
        oadvisesupplier1=request.POST.get('oadvisesupplier1',None)
        oadvisesupplier2=request.POST.get('oadvisesupplier2',None)
        oadvisesupplier3=request.POST.get('oadvisesupplier3',None)
        onumber=request.POST.get('onumber',None)
        #添加至数据库
        Order.objects.create(ocode_id=ocode,orderpp_id=orderpp,oadvisesupplier1_id=oadvisesupplier1,\
        oadvisesupplier2_id=oadvisesupplier2,oadvisesupplier3_id=oadvisesupplier3,onumber=onumber)
        print('计划提交成功')
        return render(request,'addplan.html',{'msg':'计划保存成功'})
    else:
        return render(request,'addplan.html')

#计划分配
def assignplan(request):
    orders=Order.objects.all()
    context=dict()
    context['orders']=orders
    return render(request,'assignplan.html',context)

#计划状态调整
def adjustplan(request):
    orders=Order.objects.all()
    context=dict()
    context['orders']=orders
    return render(request,'adjustplan.html',context)
#计划明细
def detailplan(request):
    orders=Order.objects.all()
    context=dict()
    context['orders']=orders
    return render(request,'detailplan.html',context)
#公司计划查看
def companyplan(request):
    if request.POST:
        ppcode=request.POST.get('ppcode',None)
        mname=request.POST.get('mname',None)
        ppname=request.POST.get('ppname',None)
        PurchasePlans1=PurchasePlan.objects.filter(ppcode__icontains=ppcode) #采购计划
        Materials=Material.objects.filter(mname__icontains=mname)
        PurchasePlans2=[] # 物料对应的采购计划集
        PurchasePlans=[]#所有采购计划
        if len(Materials)>0 :
            ordersList=Materials[0].order_set.all()
            for order_mi in ordersList:
                PurchasePlans2.append(order_mi.orderpp)
        PurchasePlans3=PurchasePlan.objects.filter(ppname__icontains=ppname) #采购计划
        PurchasePlans.append(list(PurchasePlans1))
        PurchasePlans.append(list(PurchasePlans2))
        PurchasePlans.append(list(PurchasePlans3))
        print(PurchasePlans3)
        plans=[]
        newplans=[]
        for i in PurchasePlans:
            if i:
                plans.append(i)
        if plans==[]:
            newplans=[]
        else:
            newplans=plans[0]
        for i in range(0,len(plans) ):
            for j in newplans:
                if j not in plans[i]:
                    newplans.remove(j)
        context=dict()        
        context['PurchasePlans']=newplans     
        return render(request,'companyplan.html',context)
    else:
        return render(request,'companyplan.html')

#我的计划
def showmyplan(request):
    account=request.session.get('account',None)
    deptno=list(User.objects.filter(uname=account))[0].udepartment.did
    if not account:
        return render(request,'login.html')
    else:
        if deptno == 3:
            orders=Order.objects.all()
            context=dict()
            context['orders']=orders
            return render(request,'showmyplan.html',context)
        else:
            return render(request,'tishi.html',{'msg':'仅计划员可操作访问'})

#添加物料种类
def addmaterialcategory(request):
    account=request.session.get('account',None)
    deptno=list(User.objects.filter(uname=account))[0].udepartment.did
    if not account:
        return render(request,'login.html')
    else:
        if deptno == 3:
            if request.POST:
                mcname=request.POST.get('mcname',None)
                #处理数据业务（添加数据表）
                MaterialCategory.objects.create(mcname=mcname)
                print("注册成功，数据成功添加至数据库")
                return redirect('/app/addmaterialcategory/')
            else:
                #获取数据库所有物料种类
                obj=MaterialCategory.objects.all()
                context=dict()
                context['objs']=obj
                return render(request,'addmaterialcategory.html',context)
        else:
            return render(request,'tishi.html',{'msg':'仅计划员可操作访问'})

#物料图片上传业务
def picupload(request):
    obj=request.FILES.get('file',None)
    picFileName=obj.name
    picFileSize=obj.size
    picFileStuff=os.path.splitext(picFileName)[1]
    #测试
    print('\n上传文件基本信息')
    print('-'*40)
    print('文件名称：{0}'.format(picFileName))
    print('文件大小：{0}'.format(picFileSize))
    print('文件后缀：{0}'.format(picFileStuff))
    #创建可用文件类型列表
    allowedTypes=['.png','.jpg','.gif','.bmp','.jpeg']
    if picFileStuff.lower() not in allowedTypes:
        print('文件类型不正确')
        #响应客户端
        return render(request,'addmaterial.html',{'error_msg':'错误：文件类型不正确，请重新选择一张图片'})
    #生成唯一的文件名称
    uploadUniqueName=str(uuid.uuid1()) +picFileStuff
    print('上传文件唯一名称：{0}'.format(uploadUniqueName))
        #验证上传文件夹
    uploadDirPath=os.path.join(os.getcwd(),'app/static/image')
    if not os.path.exists(uploadDirPath):
        os.mkdir(uploadDirPath)
        print('服务器上传文件夹创建完毕')
    else:
        print('服务器上传文件夹已经存在')
    picFileFullPath=uploadDirPath+os.sep+uploadUniqueName
    print('上传文件全路径：{0}'.format(picFileFullPath))
    #二进制文件写入
    try:
        #文件写入操作
        with open(picFileFullPath,'wb+') as fp:
            #将文件对象分割成多个数据块并循环写入
            for chunk in obj.chunks():
                fp.write(chunk)
            print('上传文件写入完毕')
    except:
        print('ERROR 上传文件写入服务器失败')
        return render(request,'addmaterial.html',{'error_msg':'ERROR 图片上传文件写入服务器失败'})
    #响应客户端
    picurl='/static/image/'+uploadUniqueName
    return HttpResponse(picurl)

def addmaterial(request):
    account=request.session.get('account',None)
    deptno=list(User.objects.filter(uname=account))[0].udepartment.did
    if not account:
        return render(request,'login.html')
    else:
        if deptno == 3:
            if request.POST:
                d = datetime.datetime.fromtimestamp(time.time())
                # 接收客户端请求数据
                mcode ='CGWL'+d.strftime('%Y%m%d%H%M%S%f')
                mcid=int(request.POST.get('mcname',None))#物料种类编号
                mname=request.POST.get('mname',None)
                mtype=request.POST.get('mtype',None)
                mmunit=request.POST.get('mmunit',None)
                mprice=request.POST.get('mprice',None)
                mpic=request.POST.get('photoname',None)
                mcategory=MaterialCategory.objects.get(mcid=mcid)
                #写入数据库
                Material.objects.create(mcategory=mcategory,mcode=mcode,mname=mname,mtype=mtype,mmunit=mmunit, mprice= mprice,mpic=mpic)
                print('成功添加至数据库')
                return redirect('/app/addmaterial/')
            else:
                objs=MaterialCategory.objects.all()
                Materials=Material.objects.all()
                context=dict()
                context['objs']=objs
                context['Materials']=Materials
                return render(request,'addmaterial.html',context)
        else:
            return render(request,'tishi.html',{'msg':'仅计划员可操作访问'})

def mymaterial(request):
    if request.POST:
        mcode=request.POST.get('mcode',None)
        mname=request.POST.get('mname',None)
        Materials=Material.objects.filter(mcode__icontains=mcode)
        print(Materials)
        context=dict()
        context['Materials']=Materials
        return render(request,'mymaterial.html',context)
    else:
        return render(request,'mymaterial.html')










