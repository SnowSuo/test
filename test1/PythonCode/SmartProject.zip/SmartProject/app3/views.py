from django.shortcuts import render,redirect
from app.models import User,Order,InquirySheet,PurchasePlan,BResponse,Material,TenderSheet,Company,Supplier
from django.core.paginator import Paginator,EmptyPage,PageNotAnInteger
import os,uuid


# Create your views here.
# 首页跳转
def purchaseplan(request):
    # 页面响应跳转
    return render(request,'purchaseplan.html')

# 实现询比价报价列表查看
def inquirysheetlist(request):
    # 调用函数实现按照主键进行查询检索 
    ppcode=request.POST.get('ppcode1',None)
    PurchasePlans=PurchasePlan.objects.filter(ppcode=ppcode)
    InquirySheets=InquirySheet.objects.all()
    # 创建传递参数并将数据封装到传递参数中
    content=dict()
    content['PurchasePlans']=PurchasePlans
    content['InquirySheets']=InquirySheets
    # 测试输出
    # print(PurchasePlans)
    # 页面响应跳转
    return render(request,'inquirysheetlist.html',content)
    
# 实现待处理工作创建业务 
def waittingjob(request):
    # 查询PurchasePlan表全部记录
    PurchasePlans=PurchasePlan.objects.all()
    # 创建传递参数并将数据封装到传递参数中
    content=dict()
    content['PurchasePlans']=PurchasePlans
    # 页面响应跳转
    return render(request,'waittingjob.html',content)


# 实现询比价报价操作
def offer(request):
    # 查询PurchasePlan表全部记录
    TenderSheets = TenderSheet.objects.all()
    # 查询Material表全部记录
    Materials=Material.objects.all()
    # 按照主键查询指定的项目信息
    InquirySheets=InquirySheet.objects.all()
    # 创建传递参数并将数据封装到传递参数中
    content=dict()
    content['TenderSheets']=TenderSheets
    content['Materials']=Materials
    content['InquirySheets']=InquirySheets
    # 测试输出
    print(TenderSheets)
    # 页面响应跳转
    return render(request,'offer.html',content)

# 实现中标公告发布查看
def winningnotice(request):
    content=dict()
    ppcode=request.GET.get('ppid',None)
    print(ppcode)
    PurchasePlans=[]
    TenderSheets=[]
    if ppcode is None:
        PurchasePlans=PurchasePlan.objects.all()
        # 查询TenderSheet表全部记录
        TenderSheets=Order.objects.all()
        content['TenderSheets']=TenderSheets
    else :
        PurchasePlanInfo=PurchasePlan.objects.get(ppid=ppcode)
        Orders=PurchasePlanInfo.order_set.all()
        PurchasePlans.append(PurchasePlanInfo)
        print(Orders,'------------------------------')
        TenderSheets=Orders
    # 创建传递参数并将数据封装到传递参数中
    content['PurchasePlans']=PurchasePlans
    content['TenderSheets']=TenderSheets
    return render(request,'winningnotice.html',content)

# 实现数据表数据查询
def inquirysheet(request,iscode):
    # 查询PurchasePlan表全部记录
    InquirySheets=InquirySheet.objects.filter(iscode=iscode)
    # 查询BResponse表全部记录
    BResponses=BResponse.objects.all()
    # 查询Material表全部记录
    Materials=Material.objects.all()
    # 创建传递参数并将数据封装到传递参数中
    content=dict()
    content['BResponses']=BResponses
    content['Materials']=Materials
    content['InquirySheets']=InquirySheets
    # content['PurchasePlans']=list(PurchasePlans)[0]
    # 页面响应跳转
    return render(request,'inquirysheet.html',content)

# 实现查询全部询比信息单数据
def queryAllInquirySheet(request):
    # 查询InquirySheet表全部记录
    InquirySheets = InquirySheet.objects.all()
    # 封装到传递参数中
    context = dict()
    context['InquirySheets'] = InquirySheets
    # 页面响应跳转
    return render(request,'showInquirySheet.html',context)

# 实现查询全部询比信息单数据
def queryAllBResponse(request):
    # 查询InquirySheet表全部记录
    BResponses = BResponse.objects.all()
    # 封装到传递参数中
    context = dict()
    context['BResponse'] = BResponses
    # 页面响应跳转
    return render(request,'showBResponse.html',context)


# 实现报价查询（get）
def preUpdateInquirySheet(request):
    # 按照主键查询指定的部门信息
    obj = InquirySheet.objects.all()
    # 创建传递参数并将数据封装到传递参数中
    context = dict()
    context['objs'] = obj
    # 响应客户端（页面跳转）
    return render(request, 'updateInquirySheet.html', context)

# 实现询比信息单的数据报价操作
def updateInquirySheet(request):
    if request.POST:
        # 接收客户端请求数据
        iscode =request.POST.get('iscode',None)
        istaxprice =request.POST.get('istaxprice',None)
        istaxrate =request.POST.get('istaxrate',None)
        isnote =request.POST.get('isnote',None)
        isattachment =request.POST.get('isattachment',None)
        # print(iscode)
        # print( InquirySheet.objects.filter(iscode=iscode),'ddddddddddddddddddddddddd')
        # 处理请求数据（更新操作）
        InquirySheet.objects.filter(iscode=iscode).update(istaxprice=istaxprice,istaxrate=istaxrate,isnote=isnote,isattachment=isattachment)
        print('更新成功')
        # 响应客户端
        return redirect('/InquirySheet/preupdate/')
    else:
        return render(request,'updateInquirySheet.html')


# 实现查询全部商务响应信息数据
def queryAllBResponse(request):
    # 查询InquirySheet表全部记录
    lstBResponses = BResponse.objects.all()
    # 封装到传递参数中
    context = dict()
    context['lstBResponses'] = lstBResponses
    # 页面响应跳转
    return render(request,'showBResponse.html',context)

# 多文件上传业务处理
def upload(request):
    if request.POST:
        # 接收客户端请求数据
        objs = request.FILES.getlist('uploadFile', None)
        # 处理数据
        # 检测服务器上传文件夹
        uploadPath = os.path.join(os.getcwd(), 'app3/static/file')
        if not os.path.exists(uploadPath):
            os.mkdir(uploadPath)
            print('上传文件夹创建完毕.')
            print('服务器上传文件夹地址：{0}\n'.format(uploadPath))
        else:
            print('服务器上传文件夹地址存在.')
        # 创建一个列表用于存放所有文件名称
        fileNameList = []
        # 循环objs
        for obj in objs:
            # 获取上传文件的基本信息
            print('\n上传文件信息：')
            print('-' * 40)
            print('文件名称：{0}'.format(obj.name))
            print('文件大小：{0}'.format(obj.size))
            print('文件类型：{0}\n'.format(os.path.splitext(obj.name)[1]))
            # 限制文件上传类型
            allowedTypes = ['.png', '.jpg', '.jpeg', '.gif', '.bmp','.txt']
            if os.path.splitext(obj.name)[1].lower() not in allowedTypes:
                # 响应客户端
                return render(request, 'upload.html', {'error_msg':'错误：文件类型不正确'})
            # 设置上传文件名称唯一
            uploadUniquName = str(uuid.uuid1()) + os.path.splitext(obj.name)[1]
            # 将生成的文件名称添加到列表中
            fileNameList.append('image/' + uploadUniquName)
            # 文件对象写入操作        
            # 设置上传文件服务器端全路径
            uploadFileFullPath = uploadPath + os.sep + uploadUniquName
            flag = True # 创建一个标识位
            # 文件写入操作
            try:
                with open(uploadFileFullPath, 'wb+') as fp:
                    # 将上传文件拆分成多个块（当上传文件大于2.5MB时，自动拆分）
                    for chunk in obj.chunks():
                        fp.write(chunk)
                print('{0} 服务器文件写入完毕.\n'.format(uploadUniquName))
            except:
                print('{0} 服务器文件写入失败.\n'.format(uploadUniquName))
                flag = False
                break
        # 判断标识位
        if flag:        
            # 设置传递参数
            context = dict()
            context['success_msg'] = '[OK]. 文件上传成功.'
            context['imgurls'] = fileNameList
            # 响应客户端
            return render(request, 'upload.html', context)
        else:
            # 响应客户端
            return render(request, 'upload.html', {'error_msg':'[Error]. 文件上传失败.'})
    else:
        # 响应客户端
        return render(request, 'upload.html')
